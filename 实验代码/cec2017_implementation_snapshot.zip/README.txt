Unmodified CEC2017 optimizer and statistics source inspection snapshot.
Source: LSCBO_CEC2017_WINDOWS_16C32G/source/official_cpp.
This archive identifies the implementations described in Supplementary S1.
The official evaluator and benchmark input data remain in the original reproducibility package; this inspection snapshot is not a standalone build package.

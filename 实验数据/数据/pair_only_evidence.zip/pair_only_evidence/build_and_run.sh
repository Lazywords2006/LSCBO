#!/usr/bin/env bash
set -euo pipefail
study_dir="$(cd "$(dirname "$0")" && pwd)"
repo_dir="${LSCBO_REPO_ROOT:-$(cd "$study_dir/../../../.." && pwd)}"
canonical_csv="${LSCBO_CANONICAL_CSV:-$repo_dir/论文程序及图表/LSCBO_FULL_EXPERIMENT_PROGRAM_20260609/results/formal-cloudsim_20260619_canonical/combined/final_outputs/claim_full_raw.csv}"
dependency_root="${MAVEN_REPOSITORY:-$HOME/.m2/repository}"
study_cp="$dependency_root/org/cloudsimplus/cloudsim-plus/8.0.0/cloudsim-plus-8.0.0.jar:$dependency_root/org/apache/commons/commons-math3/3.6.1/commons-math3-3.6.1.jar:$dependency_root/org/slf4j/slf4j-api/2.0.4/slf4j-api-2.0.4.jar:$dependency_root/ch/qos/logback/logback-classic/1.4.6/logback-classic-1.4.6.jar:$dependency_root/ch/qos/logback/logback-core/1.4.6/logback-core-1.4.6.jar"
study_output="${2:-$study_dir/reproductions/run-$(date -u +%Y%m%dT%H%M%SZ)}"
if [[ -e "$study_output" ]]; then
    echo "Refusing to overwrite an existing study output: $study_output" >&2
    exit 1
fi
mkdir -p "$study_dir/build"
javac --release 17 -cp "$study_cp" -d "$study_dir/build" "$study_dir/src/com/edcbo/research/claim/ClaimPreservingCloudSimExperiment.java" "$study_dir/src/com/edcbo/research/claim/PairOnlyStudy.java"
mkdir -p "$study_output"
{
    date -u
    uname -a
    java -version 2>&1
    shasum -a 256 "$canonical_csv" "$study_dir/src/com/edcbo/research/claim/ClaimPreservingCloudSimExperiment.java" "$study_dir/src/com/edcbo/research/claim/PairOnlyStudy.java"
    echo 'JVM: -Xms512m -Xmx2g -XX:+UseSerialGC'
} > "$study_output/run_metadata.txt"
java -Xms512m -Xmx2g -XX:+UseSerialGC -cp "$study_dir/build:$study_cp" com.edcbo.research.claim.PairOnlyStudy "$canonical_csv" "$study_output" "${1:-5}"

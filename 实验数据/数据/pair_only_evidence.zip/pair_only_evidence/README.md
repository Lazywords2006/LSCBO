# Supplementary Greedy-LPT plus pair-search evidence

This is a separate analytical study dated 2026-09-24. It does not replace or alter the canonical cloud dataset. No CEC benchmark or CloudSim replay was run by this study harness.

## Evidence and implementation identity

- `archive/ClaimPreservingCloudSimExperiment.java` is the unchanged archived experiment implementation, SHA-256 `390a349cb86c35a753a779ca873a2af9987b9cbcbb612fbabbd2e47eb04ee190`.
- `instrumentation.patch` lists every change in the copied executable source: scoring-call and accepted-exchange counters, a copy of the local-entry assignment, and package access for `optimize`/`localSearch`. No random draws, search formulas, acceptance decisions, candidate quotas or algorithmic branches are changed.
- The existing project implementation is the later guarded version, SHA-256 `8a6b548c1753e7cfbc969c688aa1ee59fcdab86691477303a3d64ac0ae02f315`. It was not used as the new experiment source and remains unchanged.
- Canonical input: `论文程序及图表/LSCBO_FULL_EXPERIMENT_PROGRAM_20260609/results/formal-cloudsim_20260619_canonical/combined/final_outputs/claim_full_raw.csv`; SHA-256 before and after this study is `8b7d0c3cc22350b907b70afc1d5596189e84365cc2215430df94b9fb603b16d3`.
- Full runs use the original E2 `LSCBO_full` core stream: `seed * 1_000_003L + "E2_ablation".hashCode() * 31L + "LSCBO_full".hashCode()`. They are not labeled as newly timed E4 runs.
- Both direct pair variants use the original scenario/profile/weight-derived local stream, independent of the host label. Scenario generation, Greedy-LPT, normalization, metric evaluation and pair-search procedures are called directly from the copied archive.

The full method was reproduced on all 150 task-count/seed blocks before timing. Every one of its five recorded metrics matches the canonical E2 row when rounded to the original eight decimal places. The study contains the same five task counts (200, 500, 1000, 2000, 5000), seeds 43–72, 50 VMs, default capacity profile and equal weights.

## Budget and timing protocol

Each run includes one Greedy reference evaluation and one local-entry evaluation. The full path has 600 core candidates and 5400 local candidates: 6002 actual metric calls in total. The direct 5400 path has 5402 calls; the direct 6000 path has 6002 calls. These supplementary end-to-end counts do not silently replace the historical manuscript's optimizer-internal 6001-call convention, which excludes the shared reference evaluation.

The direct paths reuse the reference assignment as their local starting point. The archived full path retains its original second Greedy construction inside `optimize`. Timing therefore compares these actual complete implementations; it does not isolate only arithmetic attributed to the continuous core.

`System.nanoTime` measures from Greedy reference construction through normalization and optimization/local search. It excludes scenario generation, assignment hashing, result validation and CSV output. The local-entry assignment copy and audit counters are inside each timed path. One application thread and Serial GC are used, with `-Xms512m -Xmx2g -XX:+UseSerialGC`. After the 150-block reproduction pass, two additional complete scale/method cycles warm all methods. Five timed repetitions use a cyclic method order; each method occupies each of the three positions exactly 250 times. Repeated timings are aggregated within each block and are not additional independent experimental scenarios.

Machine: Apple M4, 10 logical CPUs, 16 GiB RAM; macOS 27.0 (26A428); OpenJDK 25.0.2. The process uses a serial experiment loop; the desktop was not reserved exclusively, and external load, frequency and CPU affinity were not locked. These timings are supplementary measurements on this machine, not replacements for historical concurrent timings or universal speed claims.

## Main results

Elapsed time below is the mean across 150 blocks of each block's median over five runs. The uncertainty intervals resample 30 seed clusters, keeping all five fixed scales together (50,000 percentile bootstrap draws, PCG64 seed 20260924). The bootstrap seed differs from that of the original main analysis and is explicitly recorded for this supplementary analysis.

| Method | Actual calls, including reference | Mean F | Mean F reduction vs Greedy (%) | 95% cluster interval (%) | Mean accepted exchanges | Mean block-median time (ms) |
|---|---:|---:|---:|---:|---:|---:|
| Full archived LSCBO | 6002 | 0.9835267081 | 1.647329 | [1.465433, 1.837076] | 10.4867 | 23.1252 |
| Greedy-LPT + pair search, 5400 local | 5402 | 0.9835267081 | 1.647329 | [1.465433, 1.837076] | 10.4867 | 11.5682 |
| Greedy-LPT + pair search, 6000 local | 6002 | 0.9822830128 | 1.771699 | [1.584080, 1.966726] | 11.3467 | 12.8192 |

The full rerun and direct 5400 variant have identical local-entry and final assignments in all 150 blocks, verified from arrays and SHA-256 hashes. This is new rerun evidence; the original canonical CSV itself does not store assignments. Accepted exchanges range from 2 to 14 for these two paths and from 3 to 15 for the 6000 path. Mean net changed tasks relative to local entry are 20.3533 and 21.9933 respectively; this net count is not the number of distinct tasks ever touched during search.

The equal-total-call 6000 variant yields lower F in 121 blocks, equal F in 29 and higher F in zero. Its additional mean reduction is 0.12436953 percentage points of baseline-normalized F, with 95% seed-cluster interval [0.08980854, 0.16318104]. This is a separate run with a 6000-candidate local allowance, not a continuation from the 5400 endpoint: the final half-round at 5400 and the corresponding full round at 6000 may choose different assignments.

## Component comparisons: do not claim Pareto dominance over full LSCBO

Wins/ties/losses use the newly recorded double-precision component values; lower is better. Every component remains no worse than the Greedy reference in every tested block. However, the 6000 variant has greater energy than full LSCBO in 7 blocks and greater cost in 9 blocks. Thus its scalar improvement does not imply that it dominates the full method in every component.

| Component | Pair6000 vs Greedy: lower/equal/higher | Pair6000 vs full: lower/equal/higher | Mean reduction vs full | 95% cluster interval for that reduction |
|---|---:|---:|---:|---:|
| Makespan (s) | 36/114/0 | 3/147/0 | 0.0002012004 | [0, 0.0005499817] |
| Energy proxy (Wh) | 150/0/0 | 114/29/7 | 0.0034698496 | [0.0026094569, 0.0043653787] |
| Synthetic cost | 150/0/0 | 112/29/9 | 0.0026207846 | [0.0019722032, 0.0032947699] |
| Imbalance | 150/0/0 | 121/29/0 | 0.00001780284 | [0.00001213166, 0.00002412985] |

`results/pair_only_component_comparisons.csv` also contains raw component means, cluster intervals for each pair6000 mean, and paired differences/intervals relative to Greedy. These are pointwise descriptive intervals, not a family-wise multiple-hypothesis significance result. They remain conditional on the synthetic generator and tested configurations.

## Suggested manuscript paragraph

To distinguish disabled core updates from removal of the core, we conducted a separate analytical comparison using the archived implementation on the same 150 scenarios. Before this study, the full E2 LSCBO implementation reproduced all five archived metrics in every block at the original recording precision. Direct Greedy-LPT initialization followed by 5400 Pareto-safe pair evaluations produced identical initial and final assignments to the full rerun in all 150 blocks, using 5402 rather than 6002 total scoring calls when reference normalization and local-entry reevaluation are included. Reallocating the entire matched budget to 6000 local evaluations reduced mean F from 0.983527 to 0.982283, with 121 lower and 29 equal outcomes. The additional mean reduction was 0.12437 percentage points (95% seed-cluster interval: 0.08981–0.16318). All four components remained non-worse than the Greedy reference, although energy and cost were higher than those of the full method in 7 and 9 blocks, respectively. Thus, this result supports direct pair refinement under the tested conditions and provides no evidence that the continuous host is needed for the observed cloud benefit.

## Suggested timing sentence

In a separate single-threaded study on an Apple M4 machine with 16 GiB RAM and OpenJDK 25.0.2, the means of within-block median times over five warmed runs were 23.13, 11.57 and 12.82 ms for full LSCBO, direct 5400-pair search and direct 6000-pair search, respectively. Timing included reference construction, normalization and optimization, and the full archived path retained its second Greedy construction; these measurements compare the implemented paths on this machine and do not isolate causal core overhead.

## Files and reproduction

- `results/pair_only_raw.csv`: 2250 measured records, including actual calls, accepted exchanges, net changed tasks, component metrics and start/final assignment hashes.
- `results/validation.txt`: assertions from the successful original run.
- `results/pair_only_summary.json`, `pair_only_summary.csv`, `pair_only_component_comparisons.csv`: reproducible numerical summaries.
- `results/pair_only_block_timing.csv`, `pair_only_scale_timing.csv`: timing summaries without treating repeated runs as independent blocks.
- `environment.json`, `source_provenance.json`, `instrumentation.patch`: original-run machine and source identity.
- `build_and_run.sh`: uses cached Maven dependencies, compiles only into this evidence directory, and runs no Maven project build. Future runs write a new timestamped `reproductions/` directory; existing output directories are rejected to avoid stale PASS files or overwriting the retained results.
- `summarize.py`: requires NumPy and accepts an optional results-directory argument. Its complete-study validation expects five repetitions.

Run `bash build_and_run.sh 5 /absolute/path/to/new-study-output`, then `python3 summarize.py /absolute/path/to/new-study-output`. The output directory must not already exist. The default canonical path assumes the evidence directory retains its position within the project. After extracting the evidence ZIP elsewhere, set `LSCBO_REPO_ROOT` to the local LSCBO checkout or set `LSCBO_CANONICAL_CSV` to the unchanged canonical CSV. Cached dependencies must be available under `MAVEN_REPOSITORY` (default `~/.m2/repository`). The script records current Java/OS/source hashes for each future reproduction; `environment.json` describes only the retained original run.

"""Summarize the separate pair-only study without changing the canonical data."""

import csv
import hashlib
import json
import sys
from collections import defaultdict
from pathlib import Path
from statistics import mean, median

import numpy as np

ROOT = Path(__file__).resolve().parent
RESULTS = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / "results"
METHODS = ("full_archived", "pair_only_5400", "pair_only_6000")
SCALES = (200, 500, 1000, 2000, 5000)
METRICS = ("makespan", "energy", "cost", "imbalance", "objective")
EXPECTED_KEYS = {(scale, seed) for scale in SCALES for seed in range(43, 73)}


def write_csv(name, records):
    with (RESULTS / name).open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)


def main():
    with (RESULTS / "pair_only_raw.csv").open(newline="") as handle:
        rows = list(csv.DictReader(handle))
    grouped = defaultdict(list)
    for row in rows:
        key = (row["method"], int(row["taskCount"]), int(row["seed"]))
        grouped[key].append(row)
    if len(rows) != 2250 or len(grouped) != 450:
        raise ValueError("Expected 150 blocks x 3 methods x 5 repetitions")
    data = {method: {} for method in METHODS}
    timing = []
    for (method, scale, seed), repetitions in grouped.items():
        if len(repetitions) != 5 or {int(r["repetition"]) for r in repetitions} != set(range(5)):
            raise ValueError("Missing or duplicated repetitions")
        fields = METRICS + ("actualScoringCalls", "acceptedExchanges", "netChangedTasks",
                            "localStartSHA256", "finalSHA256")
        if any(len({r[field] for r in repetitions}) != 1 for field in fields):
            raise ValueError("Results changed across deterministic repetitions")
        row = repetitions[0]
        data[method][(scale, seed)] = row
        times = [float(r["elapsedMs"]) for r in repetitions]
        if not all(np.isfinite(times)) or min(times) <= 0:
            raise ValueError("Invalid elapsed time")
        timing.append(dict(method=method, taskCount=scale, seed=seed,
                           medianOfFiveMs=median(times), minOfFiveMs=min(times), maxOfFiveMs=max(times)))
    if any(set(values) != EXPECTED_KEYS for values in data.values()):
        raise ValueError("Unexpected task/seed keys")
    indices = np.random.Generator(np.random.PCG64(20260924)).integers(0, 30, (50000, 30))

    def bootstrap(values):
        clusters = np.array([mean(values[(scale, seed)] for scale in SCALES) for seed in range(43, 73)])
        return np.quantile(clusters[indices].mean(axis=1), [0.025, 0.975]).tolist()

    summaries = []
    for method in METHODS:
        values = data[method]
        improvement = {key: 100 * (1 - float(row["objective"])) for key, row in values.items()}
        ci = bootstrap(improvement)
        calls = {int(row["actualScoringCalls"]) for row in values.values()}
        if calls != ({5402} if method == "pair_only_5400" else {6002}):
            raise ValueError("Unexpected scoring budget")
        moves = [int(row["acceptedExchanges"]) for row in values.values()]
        block_medians = [row["medianOfFiveMs"] for row in timing if row["method"] == method]
        summaries.append(dict(method=method, blocks=150, actualScoringCalls=calls.pop(),
                              meanF=mean(float(row["objective"]) for row in values.values()),
                              meanReductionPercent=mean(improvement.values()), ci95Low=ci[0], ci95High=ci[1],
                              meanAcceptedExchanges=mean(moves), minAcceptedExchanges=min(moves),
                              maxAcceptedExchanges=max(moves),
                              meanNetChangedTasks=mean(int(row["netChangedTasks"]) for row in values.values()),
                              meanOfBlockMedianMs=mean(block_medians), medianOfBlockMedianMs=median(block_medians)))
    same5400 = sum(data["full_archived"][key]["finalSHA256"] == data["pair_only_5400"][key]["finalSHA256"]
                   for key in EXPECTED_KEYS)
    delta = {key: 100 * (float(data["full_archived"][key]["objective"])
                        - float(data["pair_only_6000"][key]["objective"])) for key in EXPECTED_KEYS}
    comparison = dict(pair5400IdenticalFinalAssignments=same5400,
                      pair6000LowerF=sum(value > 0 for value in delta.values()),
                      pair6000EqualF=sum(value == 0 for value in delta.values()),
                      pair6000HigherF=sum(value < 0 for value in delta.values()),
                      pair6000AdditionalReductionPercentagePoints=mean(delta.values()),
                      pair6000AdditionalReductionClusterCI95=bootstrap(delta))
    normalizers = ("normMakespan", "normEnergy", "normCost", "normImbalance")
    comparison["componentLossesAgainstReference"] = {
        method: {metric: sum(float(row[metric]) > float(row[norm]) for row in values.values())
                 for metric, norm in zip(METRICS[:4], normalizers)}
        for method, values in data.items()
    }
    component_comparisons = []
    for metric, norm in zip(METRICS[:4], normalizers):
        pair_values = {key: float(row[metric]) for key, row in data["pair_only_6000"].items()}
        pair_ci = bootstrap(pair_values)
        for baseline in ("reference", "full_archived"):
            base_values = {key: float(data["full_archived"][key][norm if baseline == "reference" else metric])
                           for key in EXPECTED_KEYS}
            differences = {key: base_values[key] - pair_values[key] for key in EXPECTED_KEYS}
            ci = bootstrap(differences)
            component_comparisons.append(dict(metric=metric, baseline=baseline,
                                              baselineMean=mean(base_values.values()),
                                              pair6000Mean=mean(pair_values.values()),
                                              pair6000MeanCI95Low=pair_ci[0], pair6000MeanCI95High=pair_ci[1],
                                              meanPairedReduction=mean(differences.values()),
                                              reductionCI95Low=ci[0], reductionCI95High=ci[1],
                                              lower=sum(value > 0 for value in differences.values()),
                                              equal=sum(value == 0 for value in differences.values()),
                                              higher=sum(value < 0 for value in differences.values())))
    scale_timing = [dict(method=method, taskCount=scale,
                         meanOfBlockMedianMs=mean(row["medianOfFiveMs"] for row in timing
                                                  if row["method"] == method and row["taskCount"] == scale))
                    for method in METHODS for scale in SCALES]
    write_csv("pair_only_summary.csv", summaries)
    write_csv("pair_only_block_timing.csv", timing)
    write_csv("pair_only_scale_timing.csv", scale_timing)
    write_csv("pair_only_component_comparisons.csv", component_comparisons)
    summary = dict(methods=summaries, comparison=comparison, components=component_comparisons,
                   uncertainty="30 seed clusters, each retaining 5 scales; 50000 resamples; PCG64 seed 20260924",
                   rawSha256=hashlib.sha256((RESULTS / "pair_only_raw.csv").read_bytes()).hexdigest())
    (RESULTS / "pair_only_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()

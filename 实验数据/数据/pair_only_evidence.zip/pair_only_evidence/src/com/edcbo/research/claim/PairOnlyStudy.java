package com.edcbo.research.claim;

import java.io.PrintWriter;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import static com.edcbo.research.claim.ClaimPreservingCloudSimExperiment.*;

/** Supplementary, analytical-only study using the archived experiment methods. */
public final class PairOnlyStudy {
    private static final int[] SCALES = {200, 500, 1000, 2000, 5000};
    private static final String[] METHODS = {"full_archived", "pair_only_5400", "pair_only_6000"};
    private static final WeightProfile WEIGHTS = WeightProfile.W0_EQUAL;
    private static final VmProfile PROFILE = VmProfile.DEFAULT;

    private record Observation(String method, int tasks, long seed, Metrics metrics, Norm norm,
                               int[] schedule, int[] localStart, long scoreCalls, int moves,
                               int coreCandidates, int localCandidates, double elapsedMs) {}

    private static Observation run(Scenario scenario, int method) {
        auditScoringCalls = 0;
        auditAcceptedExchanges = 0;
        auditLocalStart = null;
        long start = System.nanoTime();
        int[] reference = greedyReferenceSchedule(scenario);
        Norm norm = new Norm(evaluateRaw(reference, scenario, WEIGHTS, null));
        int[] schedule;
        Metrics metrics;
        int coreCandidates;
        int localCandidates;
        if (method == 0) {
            long coreSeed = scenario.seed * 1_000_003L
                    + "E2_ablation".hashCode() * 31L + "LSCBO_full".hashCode();
            OptimizationResult result = optimize(Algorithm.LSCBO, FeatureSet.lscbo(), scenario,
                    WEIGHTS, norm, coreSeed);
            schedule = result.schedule;
            metrics = result.metrics;
            coreCandidates = result.initialEvaluations + result.iterationEvaluations;
            localCandidates = result.localSearchEvaluations;
        } else {
            long localSeed = 0x5DEECE66DL ^ (scenario.seed * 1_000_003L)
                    ^ ((long) scenario.taskCount << 17)
                    ^ ((long) scenario.vmProfile.ordinal() << 9) ^ WEIGHTS.ordinal();
            LocalSearchResult result = localSearch(reference, scenario, WEIGHTS, norm,
                    new Random(localSeed), method == 1 ? 5400 : 6000,
                    LocalSearchMode.PAIR_PARETO);
            schedule = result.schedule;
            metrics = result.metrics;
            coreCandidates = 0;
            localCandidates = result.evaluations;
        }
        double elapsedMs = (System.nanoTime() - start) / 1_000_000.0;
        long expectedCalls = method == 1 ? 5402 : 6002;
        if (auditScoringCalls != expectedCalls) {
            throw new IllegalStateException("Actual scoring-call mismatch: " + auditScoringCalls);
        }
        return new Observation(METHODS[method], scenario.taskCount, scenario.seed, metrics, norm,
                schedule, auditLocalStart, auditScoringCalls, auditAcceptedExchanges,
                coreCandidates, localCandidates, elapsedMs);
    }

    private static String hash(int[] schedule) throws Exception {
        ByteBuffer bytes = ByteBuffer.allocate(schedule.length * Integer.BYTES);
        for (int vm : schedule) bytes.putInt(vm);
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes.array()));
    }

    private static double[] metricValues(Metrics m) {
        return new double[]{m.makespan, m.energy, m.cost, m.imbalance, m.objective};
    }

    private static Map<String, String[]> canonical(Path path) throws Exception {
        List<String> lines = Files.readAllLines(path);
        List<String> header = Arrays.asList(lines.get(0).split(","));
        String[] names = {"makespan", "energy", "cost", "imbalance", "objective"};
        Map<String, String[]> expected = new HashMap<>();
        for (int line = 1; line < lines.size(); line++) {
            String[] row = lines.get(line).split(",");
            if (!row[header.indexOf("experiment")].equals("E2_ablation")
                    || !row[header.indexOf("variant")].equals("LSCBO_full")) continue;
            String[] values = new String[names.length];
            for (int i = 0; i < names.length; i++) values[i] = row[header.indexOf(names[i])];
            String key = row[header.indexOf("taskCount")] + "/" + row[header.indexOf("seed")];
            if (expected.put(key, values) != null) throw new IllegalStateException("Duplicate " + key);
        }
        if (expected.size() != 150) throw new IllegalStateException("Expected 150 archived full blocks");
        return expected;
    }

    private static void validateCanonical(Observation value, Map<String, String[]> canonical) {
        String key = value.tasks + "/" + value.seed;
        String[] expected = canonical.get(key);
        double[] actual = metricValues(value.metrics);
        for (int i = 0; i < actual.length; i++) {
            String rounded = String.format(Locale.ROOT, "%.8f", actual[i]);
            if (!rounded.equals(expected[i])) {
                throw new IllegalStateException("Archived reproduction differs at " + key
                        + " metric " + i + ": " + rounded + " vs " + expected[i]);
            }
        }
    }

    private static void write(PrintWriter output, Observation row, int repetition, int order)
            throws Exception {
        output.printf(Locale.ROOT, "%s,%d,%d,%d,%d,%d,%d,%d,%d,%d,%.9f",
                row.method, row.tasks, row.seed, repetition, order, row.scoreCalls,
                row.coreCandidates, row.localCandidates, row.moves,
                changedTasks(row.localStart, row.schedule), row.elapsedMs);
        for (double value : metricValues(row.metrics)) output.printf(Locale.ROOT, ",%.17g", value);
        output.printf(Locale.ROOT, ",%.17g,%.17g,%.17g,%.17g,%s,%s%n",
                row.norm.makespan, row.norm.energy, row.norm.cost, row.norm.imbalance,
                hash(row.localStart), hash(row.schedule));
    }

    private static int changedTasks(int[] before, int[] after) {
        int changes = 0;
        for (int i = 0; i < before.length; i++) if (before[i] != after[i]) changes++;
        return changes;
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 3) throw new IllegalArgumentException("canonical.csv output-directory repeats");
        Locale.setDefault(Locale.ROOT);
        Path out = Path.of(args[1]);
        Files.createDirectories(out);
        int repeats = Integer.parseInt(args[2]);
        if (repeats < 1) throw new IllegalArgumentException("repeats must be positive");
        Map<String, String[]> expected = canonical(Path.of(args[0]));
        // Validate every full configuration before the timed study; retain its exact assignments.
        Map<String, Observation> reproduced = new HashMap<>();
        for (int tasks : SCALES) {
            for (long seed = 43; seed <= 72; seed++) {
                Observation row = run(createScenario(tasks, 50, seed, PROFILE), 0);
                validateCanonical(row, expected);
                reproduced.put(tasks + "/" + seed, row);
            }
            System.out.println("Archived reproduction verified: N=" + tasks + ", 30 blocks");
        }
        // Two complete scale/method cycles warm all three paths; outputs are discarded.
        for (int cycle = 0; cycle < 2; cycle++) {
            for (int tasks : SCALES) {
                Scenario scenario = createScenario(tasks, 50, 43 + cycle, PROFILE);
                for (int method = 0; method < METHODS.length; method++) run(scenario, method);
            }
        }
        try (PrintWriter raw = new PrintWriter(Files.newBufferedWriter(out.resolve("pair_only_raw.csv")))) {
            raw.println("method,taskCount,seed,repetition,order,actualScoringCalls,coreCandidates,localCandidates,acceptedExchanges,netChangedTasks,elapsedMs,makespan,energy,cost,imbalance,objective,normMakespan,normEnergy,normCost,normImbalance,localStartSHA256,finalSHA256");
            Map<String, String> previousHashes = new HashMap<>();
            for (int repetition = 0; repetition < repeats; repetition++) {
                int block = 0;
                for (int tasks : SCALES) {
                    for (long seed = 43; seed <= 72; seed++) {
                        Scenario scenario = createScenario(tasks, 50, seed, PROFILE);
                        for (int order = 0; order < METHODS.length; order++) {
                            int method = (block + repetition + order) % METHODS.length;
                            Observation row = run(scenario, method);
                            Observation full = reproduced.get(tasks + "/" + seed);
                            if (method == 0) validateCanonical(row, expected);
                            if (method <= 1 && (!Arrays.equals(row.schedule, full.schedule)
                                    || !Arrays.equals(row.localStart, full.localStart))) {
                                throw new IllegalStateException("Full/pair5400 schedule mismatch at " + tasks + "/" + seed);
                            }
                            String key = row.method + "/" + tasks + "/" + seed;
                            String digest = hash(row.schedule);
                            String previous = previousHashes.putIfAbsent(key, digest);
                            if (previous != null && !previous.equals(digest)) {
                                throw new IllegalStateException("Nondeterministic result " + key);
                            }
                            write(raw, row, repetition, order);
                        }
                        block++;
                    }
                }
                raw.flush();
                if (raw.checkError()) throw new IllegalStateException("CSV write failure");
                System.out.println("Completed repetition " + (repetition + 1) + "/" + repeats);
            }
        }
        Files.writeString(out.resolve("validation.txt"),
                "PASS: archived full reproduced in all 150 blocks, all five metrics at archive precision.\n"
                + "PASS: full and pair5400 have identical start/final assignments in all 150 blocks.\n"
                + "PASS: actual calls are full=6002, pair5400=5402, pair6000=6002 including reference.\n"
                + "PASS: all recorded repetitions have deterministic final assignment hashes.\n"
                + "Timing includes greedy reference, normalization and optimizer/local entry; excludes scenario generation, hashing and output.\n"
                + "The full archived path retains its second greedy construction; the direct pair path reuses its reference schedule.\n"
                + "Single application thread; two explicit warmup cycles after the 150-block reproduction pass.\n"
                + "Repetitions=" + repeats + "\n");
        System.out.println("All checks passed.");
    }
}
